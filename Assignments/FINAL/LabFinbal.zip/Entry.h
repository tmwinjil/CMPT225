#include<string.h>
#include<iostream>
using namespace std;

class Entry {
public:
    Entry();
    Entry(const Entry & e);
    Entry(int m, int d, string s);
    Entry(int m, int d, char* word);

    void printEntry();
    int month;
    int day;
    char initials[3];
};