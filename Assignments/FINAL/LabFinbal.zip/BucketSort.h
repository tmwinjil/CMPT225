#ifndef BUCKETSORT_H
#define BUCKETSORT_H
#include<vector>
#include "Entry.h"
using namespace std;

class BucketSort {
    BucketSort();

    Vector<Entry>* sortVector(vector<Entry> v);
    friend void stableSort(vector<Entry> v, int max)
}

#endif