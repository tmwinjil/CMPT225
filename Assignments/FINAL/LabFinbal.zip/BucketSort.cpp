#include "BucketSort.h"
using namespace std;

BucketSort()
{
    ;
}

Vector<Entry>* BucketSort::sortVector(vector<Entry> v)
{


    for (int i = 2 ; i >= 0; i--)
        stableSort(v, i)
}

void  stableSort(vector<Entry> v, int selector) 
{
    Entry e[31];


}