/*
 * BSTree.cpp
 *
 *  Created on: Mar 5, 2010
 *      Author: mori
 */

#include "BSTree.h"


BSTree::BSTree() {
}


BSTree::~BSTree() {
}


bool BSTree::insert(string x, char y, int z) {
	return false;
}


bool BSTree::remove(string x, char y) {
	return false;
}


bool BSTree::search(string x, char y) {
	return false;
}


vector<Customer> BSTree::rangeSearch(string x, char y, string z, char a) {
}


void BSTree::inOrderPrint() {
}


