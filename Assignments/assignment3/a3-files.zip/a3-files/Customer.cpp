/*
 * Customer.cpp
 *
 *  Created on: Mar 5, 2010
 *      Author: mori
 */

#include "Customer.h"

Customer::Customer(string x, char y, int z) {
}


ostream& operator<<(ostream & os,  Customer & c) {
}
